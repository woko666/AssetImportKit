//
//  AssetImportKit.h
//  AssetImportKit
//
//  Created by Eugene Bokhan on 2/11/18.
//  Copyright © 2018 Eugene Bokhan. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AssetImportKit.
FOUNDATION_EXPORT double AssetImportKitVersionNumber;

//! Project version string for AssetImportKit.
FOUNDATION_EXPORT const unsigned char AssetImportKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AssetImportKit/PublicHeader.h>
#import "Dependencies/Assimp/Assimp C API/PostProcessingFlags.h"

